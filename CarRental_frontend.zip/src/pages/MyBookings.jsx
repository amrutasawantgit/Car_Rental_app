import { useEffect, useState } from 'react'
import {assets} from '../assets/assets'
import Title from '../components/Title'
import { useAppContext } from '../context/AppContext'
import toast from 'react-hot-toast'
import {motion} from 'motion/react'

const MyBookings = () => {

  const {currency, user, axios} = useAppContext()

  const [booking, setBooking] = useState([])
  
  const fetchMyBookings = async () => {
    try {
      const {data} =  await axios.get('api/booking/user', {
        headers: { 'Cache-Control': 'no-cache' }
      })
      //console.log("Bookings response:", data);
      
      if(data.success){
        setBooking(data.booking || [])
      }else{
        toast.error(data.message)
      }
    } catch (error) {
        toast.error(error.message)
    }
  }

  useEffect(()=>{
    user && fetchMyBookings()
  },[user])
//   useEffect(() => {
//   console.log("User in MyBookings:", user);
//   if (user) fetchMyBookings();
// }, [user]);


  return (
    <motion.div 
    initial={{ y: 30, opacity: 0 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.6}}
    className='px-6 md:px-16 lg:px-24 xl:px-32 2xl:px-48 mt-16 text-sm max-w-7xl'>

      <Title title="My Bookings" subTitle="View and manage your all car bookings." align="left"/>

      <div>
        {booking.map((booking, index)=>(
          <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: index * 0.1}} 

          key={booking._id} className='grid grid-cols-1 md:grid-cols-4 gap-6 p-6 border border-borderColor 
          rounded-lg mt-5 first:mt-12'>
            {/* Car image + info */}
            <div className='md:col-span-1'>
              <div className='rounded-md overflow-hidden mb-3'>
                <img src={booking.car.image} alt="" className='w-full h-auto aspect-video object-cover' />
              </div>

              <p className='text-lg font-medium mt-2'>{booking.car.brand}{booking.car.model}</p>

              <p className='text-gray-500'>{booking.car.year} * {booking.car.category} * {booking.car.location}</p>
            </div>

            {/* Booking info */}
            <div className='md:col-span-2'>
                <div className='flex items-center gap-2'>
                    <p className='px-3 py-1.5 bg-light rounded'>Booking #{index+1}</p>
                    <p className={`px-3 py-1 text-xs rounded-full ${booking.status === 'confirmed' ? 'bg-green-400/15 text-green-600'
                      : 'bg-red-400/15 text-red-600'} `}>{booking.status}</p>
                </div>

                <div className='flex gap-2 items-start mt-3'>
                  <img src={assets.calendar_icon_colored} alt="" className='w-4 h-4 mt-1'/>
                  <div>
                      <p className='text-gray-500'>Rental Period</p>
                      <p>{booking.pickupDate.split('T')[0]} To {booking.returnDate.split('T')[0]}</p>
                  </div>
                </div>
                <div className='flex gap-2 items-start mt-3'>
                  <img src={assets.calendar_icon_colored} alt="" className='w-4 h-4 mt-1'/>
                  <div>
                      <p className='text-gray-500'>Pick-up Location</p>
                      <p>{booking.car.location}</p>
                  </div>
                </div>
            </div>

            {/* Price */}
            <div className='md:col-span-1 flex flex-col gap-6 justify-between'>
              <div className='text-sm text-gray-500 text-right'>
                <p>Total Price</p>
                <h1 className='text-2xl font-semibold text-primary'>{currency}${booking.price}</h1>
                <p>Booked on {booking.createdAt.split('T')[0]}</p>
              </div>

            </div>

          </motion.div>
        ))}
      </div>

    </motion.div>
  )
}

export default MyBookings