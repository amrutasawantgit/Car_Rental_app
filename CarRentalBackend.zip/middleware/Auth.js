// import jwt from 'jsonwebtoken';
// import User from '../models/User.js';


// export const protect = async (req,res,next) => {
//     const token = req.headers.authorization;
//     if(!token) {
//         return res.json({success:false, message:"Not authorized"})
//     }
//     try {
//         const userId = jwt.decode(token, process.env.JWT_SECRET)

//         if(!userId){
//             return res.json({success:false, message:"Not authorized."})
//         }
//         req.user = await User.findById(userId).select('-password');
//         next();
//     } catch (error) {
//         return res.json({success:false, message:"Not authorized"})
//     }

// }

import jwt from "jsonwebtoken";
import User from "../models/User.js";

export const protect = async (req, res, next) => {
  const token = req.headers.authorization;
  if (!token) {
    return res.json({ success: false, message: "Not authorized, no token" });
  }

  try {
    // ✅ verify and decode with secret
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    if (!decoded || !decoded.id) {
      return res.json({ success: false, message: "Not authorized, invalid token" });
    }

    // ✅ attach user to request (exclude password)
    req.user = await User.findById(decoded.id).select("-password");

    if (!req.user) {
      return res.json({ success: false, message: "User not found" });
    }

    next();
  } catch (error) {
    return res.json({ success: false, message: "Not authorized, token failed" });
  }
};
